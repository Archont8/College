/*
*   Практическая работа 5
*   Выполнил Сафронов Данил
*   Проверил преподаватель Фомин А.Т.
*   Задание:
*/
#include "Vectors.h"
#include <fstream>
using namespace std;

int main()
{
    Vectors::Initialize();
}
