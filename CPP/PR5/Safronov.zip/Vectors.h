#pragma once
#ifndef VECTORS_H
#define VECTORS_H
#include <vector>
#include <array>

	class Vectors
	{
	public:
		static void Initialize();
	private:
		void ArrayAndMasShift(int[], array<int, 10>);
	};
#endif
